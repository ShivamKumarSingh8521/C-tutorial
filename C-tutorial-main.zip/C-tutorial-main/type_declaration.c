#include <stdio.h>
int main()
{
    int a=4, b, c;
b=c=a;
printf("the value of a is %d\n",a);
printf("the value of b is %d\n",b);
printf("the value of c is %d\n",c);
return 0;
}

#include <stdio.h>
int main()
{
   int length =5, breath =6;
  
    printf("area of this rectangle is %d",length*breath);
return 0;
}



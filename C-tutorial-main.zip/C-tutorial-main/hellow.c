#include<stdio.h>
int main (){
    printf("shivam kumar singh");
    return 0;
}
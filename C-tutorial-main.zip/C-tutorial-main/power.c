#include <stdio.h>
#include <math.h>
int main()
{
    int a = 4;
    int b = 5;
    int pow;
    printf("the value of 4 to the power 5 if %f\n"pow(4,5));
    return 0;

}
#include <stdio.h>
int main()
{
    float a,b; 
    printf(" enter the values of a and b");
    scanf("%f%f",&a,&b);
    printf("divide of a and b is %f",a/b);
return 0;
}
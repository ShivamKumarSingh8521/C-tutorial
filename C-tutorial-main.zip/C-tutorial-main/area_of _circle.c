#include <stdio.h>
int main()
{
    int radius = 5;
    float pi =3.14;
    printf("the area of this circle %f",pi*radius*radius);

return 0;
}

#include <stdio.h>
int main()
{
    int a = 0;
    if (a=printf("hi"))
    {
        printf("%d",a);
    }
    else
    {
        printf("%d",a+1);
    }
return 0;
}
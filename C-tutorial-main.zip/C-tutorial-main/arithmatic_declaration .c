#include <stdio.h>
int main()
{
    int a = 4;
    int b = 5;
    printf("the value of a+b is %d\n",(a+b));
    printf("the value of a-b is %d\n",(a-b));
    printf("the value of a*b is %d\n",(a*b));
    printf("the value of b/a is %d\n",(b/a));
    return 0;
}
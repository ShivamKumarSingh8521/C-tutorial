#include <stdio.h>
int main()
{
    float a=5.5;
    float b= a+6.5;
    printf("the value of b is %f\n",b);
return 0;
}
#include <stdio.h>
int main()
{
    int a = 4;
    int b= 10, z = b* a;
    
    printf("the value of a+b is %d\n",a+b);
    
    printf("the value of a-b is %d\n",a-b);
   
   
    printf("the value of a*b is %d\n",a*b);
   
   
    printf("the value of a/b is %d\n",a/b);
    
   
    printf(" 5 when divides by 2 leaves a remainder of %d\n",5%2);
   
    
return 0;
}
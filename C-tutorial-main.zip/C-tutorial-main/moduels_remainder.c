#include <stdio.h>
int main()
{
    int a =5;
    int b = 2;
    printf("5 when divides by 2 leaves a emainder %d\n",a%b);
return 0;
}
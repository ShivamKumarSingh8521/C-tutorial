#include <stdio.h>
int main()
{
    int a,b; 
    printf("enter the value of a and b ");
    scanf("%d%d",&a,&b);
    printf("multiplication of a and b is %d\n",a*b);
return 0;
}
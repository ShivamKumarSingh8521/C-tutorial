#include <stdio.h> 
int main()
{
    float celcius =37;
   int far =(celcius * 9/5) +32;
    printf("the value of this celcius temperature in fahrenheit is %f",far);

return 0;
}